import streamlit as st
import pandas as pd

# Cargar el archivo CSV
df = pd.read_csv("portafolio_andean_jul2025.csv")

st.set_page_config(page_title="Recomendador de Sabores", layout="wide")
st.title("Recomendador de Sabores - Portafolio Andean")

# Mostrar los datos originales si se desea
if st.checkbox("Mostrar datos originales"):
    st.dataframe(df)

# Selección de columnas relevantes
columnas = df.columns.tolist()
col_aplicacion = st.selectbox("Selecciona la columna de Aplicación", columnas)
col_perfil = st.selectbox("Selecciona la columna de Perfil de Sabor", columnas)

# Filtros
aplicaciones = df[col_aplicacion].dropna().unique()
aplicacion_seleccionada = st.selectbox("Filtrar por aplicación", sorted(aplicaciones))

perfil_input = st.text_input("Filtrar por palabra clave en perfil de sabor (ej. frutal, cremoso)")

# Aplicar filtros
resultado = df[df[col_aplicacion] == aplicacion_seleccionada]

if perfil_input:
    resultado = resultado[resultado[col_perfil].str.contains(perfil_input, case=False, na=False)]

# Mostrar resultados
st.subheader("Sabores recomendados")
st.dataframe(resultado.reset_index(drop=True))
