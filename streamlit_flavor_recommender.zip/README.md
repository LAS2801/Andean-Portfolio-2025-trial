
# 📊 Recomendador de Sabores - Portafolio Andean

Esta aplicación web desarrollada con **Streamlit** permite explorar y recomendar sabores del portafolio Andean según criterios como **aplicación** (bebidas, lácteos, snacks, etc.) y **perfil de sabor** (frutal, cremoso, especiado, etc.).

---

## 📁 Contenido del repositorio

- `app.py`: Script principal de la aplicación Streamlit.
- `portafolio_andean_jul2025.csv`: Base de datos consolidada de sabores extraída del archivo Excel original.

---

## 🚀 Cómo desplegar en Streamlit Cloud

1. Crea una cuenta en [Streamlit Cloud](https://streamlit.io/cloud) e inicia sesión con GitHub.
2. Crea un nuevo repositorio en GitHub y sube los archivos `app.py` y `portafolio_andean_jul2025.csv`.
3. En Streamlit Cloud, haz clic en **“New app”**.
4. Selecciona el repositorio y configura:
   - **Branch**: `main`
   - **Main file path**: `app.py`
5. Haz clic en **“Deploy”** y tu app estará disponible en una URL pública.

---

## 🧪 Cómo usar la aplicación

1. Selecciona la columna que representa la **aplicación** (por ejemplo, `Application`).
2. Selecciona la columna que representa el **perfil de sabor** (por ejemplo, `C&D Comments`).
3. Filtra por una aplicación específica.
4. Ingresa palabras clave como `frutal`, `cremoso`, `cítrico`, etc.
5. Visualiza los sabores recomendados en tiempo real.

---

## 👥 Cómo colaborar

Si deseas contribuir al proyecto:

- Revisa el archivo `app.py` para entender la lógica de filtrado.
- Puedes proponer mejoras en la interfaz, visualizaciones o agregar nuevas funcionalidades.
- Usa `pull requests` para sugerir cambios.
- Reporta errores o ideas en la sección de **Issues** del repositorio.

---

## 📬 Contacto

Para dudas o sugerencias, puedes abrir un issue o contactar al administrador del repositorio.

